from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path


NOTEBOOK_FILENAME = "engineering_notebook.json"


@dataclass
class EngineeringNotebook:
    hardware_configuration: str = ""
    modifications: str = ""
    test_conditions: str = ""
    acquisition_summary: str = ""
    analysis_highlights: str = ""
    observations: str = ""
    conclusions: str = ""
    next_actions: str = ""
    photo_paths: list[str] = field(default_factory=list)
    updated_utc: str = ""

    def touch(self) -> None:
        self.updated_utc = datetime.now(timezone.utc).isoformat()


def notebook_path(session: Path) -> Path:
    return Path(session) / NOTEBOOK_FILENAME


def load_notebook(session: Path) -> EngineeringNotebook:
    path = notebook_path(session)
    if not path.exists():
        return EngineeringNotebook()

    data = json.loads(path.read_text(encoding="utf-8"))
    allowed = set(EngineeringNotebook.__dataclass_fields__)
    return EngineeringNotebook(
        **{key: value for key, value in data.items() if key in allowed}
    )


def save_notebook(session: Path, notebook: EngineeringNotebook) -> Path:
    session = Path(session)
    session.mkdir(parents=True, exist_ok=True)
    notebook.touch()
    path = notebook_path(session)
    path.write_text(
        json.dumps(asdict(notebook), indent=2),
        encoding="utf-8",
    )
    return path
